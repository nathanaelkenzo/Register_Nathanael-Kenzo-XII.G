<script type="text/javascript">
    document.getElementById('registerForm').addEventListener('submit', function(e) {
        e.preventDefault();// mencegah refresh halaman

        // Ambil data dari form
        const nama = document.getElementById('nama').value;
        const email = document.getElementById('email').value;
        const nomorHp = document.getElementById('nomor hp').value;
        const tanggalLahir = document.getElementById('date').value;

        // Buat objek data
        const data = {
            nama: nama,
            email: email,
            nomorHp: nomorHp,
            tanggalLahir: tanggalLahir
        };

        // Tambahkan ke tabel HTML
        const table = document.getElementById('datatable');
        const row = table.insertRow(-1);
        row.insertCell(0).textContent = nama;
        row.insertCell(1).textContent = email;
        row.insertCell(2).textContent = tanggalLahir;
        row.insertCell(3).textContent = '-';

        // Simpan data ke file JSON
        const fileData = JSON.stringify(data, null, 2);
        const blob = new Blob([fileData], { type: "application/json" });
        const url = URL.createObjectURL(blob);

        // Buat dan klik link download
        const a = document.createElement("a");
        a.href = url;
        a.download = `data-${nama}.json`;
        a.click();

        // Bersihkan form
        document.getElementById('registerForm').reset();
    });
</script>